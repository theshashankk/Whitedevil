#kang krne aaye ho  chala ja bhosdike tere kaam ka ni h ye
#make by legendx22 for chutiapa 🤔😑 you dont kang this 
#okay to ab isme cheeze bharte h 
#if you read only this then okay else
#chala jaa bhosdike 
from userbot import ALIVE_NAME 
MASTER = str(ALIVE_NAME) if ALIVE_NAME else "LEGEND BOY"

#op for keinshin

Keinshin = "[KEINSHIN](https://t.me/keinshin)"
OP = "[BLACK LIGHTNING](https://github.com/KeinShin/Black-Lightning)"
OKAY = "[SUPPORT GROUP](https://t.me/LIGHTINGSUPPORT)"
#itna test h aur aage krte h
#test successful raha ab aage 
ALIVE = "BLACK LIGHTNING BOT IS ON 🔥 FIRE 🔥" #make by LEGENDX22 for black lightning
BOT = " HELLO MASTER MY NAME IS BLACK LIGHTNING BOT I AM A BEST USERBOT 💝"
EMOJI = "⚡"
#yrr isko apne bot me aply krne se pehle mere se pooch lena ok
#aur aage add kruga abhi busy okay 🤔
