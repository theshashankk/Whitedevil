# PokeBot
Like the pokemon game but on Telegram.
